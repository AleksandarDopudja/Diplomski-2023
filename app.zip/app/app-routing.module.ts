import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { ServicesComponent } from './services/services.component';
import { ProductsComponent } from './products/products.component';
import { MachinesComponent } from './machines/machines.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { AdduserComponent } from './adduser/adduser.component';
import { AdminrequestsComponent } from './adminrequests/adminrequests.component';
import { AllstoragesComponent } from './allstorages/allstorages.component';
import { StoragedetailsComponent } from './storagedetails/storagedetails.component';
import { OrgpageComponent } from './orgpage/orgpage.component';
import { AlllocationsComponent } from './alllocations/alllocations.component';
import { LocationdetailsComponent } from './locationdetails/locationdetails.component';
import { GarageComponent } from './garage/garage.component';
import { DistributionComponent } from './distribution/distribution.component';
import { MachineunitdetailsComponent } from './machineunitdetails/machineunitdetails.component';
import { UserpageComponent } from './userpage/userpage.component';
import { DisordsComponent } from './disords/disords.component';
import { DiorddetailsComponent } from './diorddetails/diorddetails.component';
import { ClientpageComponent } from './clientpage/clientpage.component';
import { ClinetreqdetailsComponent } from './clinetreqdetails/clinetreqdetails.component';

const routes: Routes = [
  {path: '', component: WelcomepageComponent},
  {path: 'services', component: ServicesComponent},
  {path: 'products', component: ProductsComponent},
  {path: 'aparates', component: MachinesComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'adminpage', component: AdminpageComponent},
  {path: 'adminlogin', component: AdminloginComponent},
  {path: 'userdetails', component: UserdetailsComponent},
  {path: 'adduser', component: AdduserComponent},
  {path: 'adminrequests', component: AdminrequestsComponent},
  {path: 'storages', component: AllstoragesComponent},
  {path: 'storagedetails', component: StoragedetailsComponent},
  {path: 'orgpage', component: OrgpageComponent},
  {path: 'locations', component: AlllocationsComponent},
  {path: 'locationdetails', component: LocationdetailsComponent},
  {path: 'garage', component: GarageComponent},
  {path: 'distribution', component: DistributionComponent},
  {path: 'machineunitdetails', component: MachineunitdetailsComponent},
  {path: 'userpage', component: UserpageComponent},
  {path: 'disorder', component: DisordsComponent},
  {path: 'disorderdetails', component: DiorddetailsComponent},
  {path: 'clentpage', component: ClientpageComponent},
  {path:'clientreqdetails', component: ClinetreqdetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
