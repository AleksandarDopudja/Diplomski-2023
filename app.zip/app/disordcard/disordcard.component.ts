import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { DisOrder } from '../models/disorder';

@Component({
  selector: 'app-disordcard',
  templateUrl: './disordcard.component.html',
  styleUrls: ['./disordcard.component.css']
})
export class DisordcardComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() disord: DisOrder;

  goDetails(){
    sessionStorage.setItem('disorddetails', JSON.stringify(this.disord));
    this.router.navigate(['../disorderdetails']);
  }
}
