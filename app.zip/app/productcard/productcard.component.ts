import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Product } from '../models/product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productcard',
  templateUrl: './productcard.component.html',
  styleUrls: ['./productcard.component.css']
})
export class ProductcardComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() product: Product;

  goDetails(){
    sessionStorage.setItem('currproductdetails', JSON.stringify(this.product));
    this.router.navigate(['../productdetails']);
  }
}
