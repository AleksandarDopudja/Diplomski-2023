import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  constructor(private userService: UserserviceService,private router: Router) { }

  ngOnInit(): void {
  }

  username: string = "";
  password: string = "";
  type: number = 0;

  message: string = "";

  login(){
    sessionStorage.clear();
    if(this.username == "" || this.password == ""){
      this.message = "Nisu uneta sva polja!";
    }
    else{
      this.userService.login(this.username, this.password).subscribe((user:User)=>{

        sessionStorage.setItem('currlogin',JSON.stringify(user));
        sessionStorage.setItem('currlocationdetails',JSON.stringify(null));
        if(user){
          if(user.status==1){
            if(user.type==3){
              this.router.navigate(['/userpage']);
            }else if(user.type==2){
              this.router.navigate(['/orgpage']);
            }else if(user.type==1){
              this.router.navigate(['/clentpage']);
            }
          }else if(user.status==0){
            this.message ="Vas zahtev za registraciju jos nije obradjen od strane administratora!";
          }
        }
        else {
          this.message = "Neispravno uneti podaci!";
        }
      })
    }
  }

}
