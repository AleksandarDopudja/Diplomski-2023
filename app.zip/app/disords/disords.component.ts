import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { DisOrder } from '../models/disorder';

@Component({
  selector: 'app-disords',
  templateUrl: './disords.component.html',
  styleUrls: ['./disords.component.css']
})
export class DisordsComponent implements OnInit {
  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Aktivni", "Predhodni"];

  disorders: DisOrder[] = [];

  orgdisorders: DisOrder[] = [];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    sessionStorage.setItem('curruserdetails',JSON.stringify(this.loginuser));

    this.service.getDistributionOrders(this.loginuser.username).subscribe((ords: DisOrder[])=>{
      //this.disorders = ords;
      this.orgdisorders = ords.slice();
      this.disorders = ords.filter(w=>w.status=='aktivan');
    });

  }

  search(i){
    
    this.curr = i-1;
    //sessionStorage.setItem('currlocationdetails',JSON.stringify(null));
    let str = "";
    if(this.curr==0){
      str="aktivan";
    }
    else{
      str="neaktivan";
    }
    this.disorders = this.orgdisorders.slice();
    this.disorders = this.disorders.filter(w=>w.status===str);
  }

}
