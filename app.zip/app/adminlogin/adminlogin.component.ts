import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(private userService: UserserviceService,private router: Router) { }

  username: string = "";
  password: string = "";
  type: number = 0;

  message: string = "";

  ngOnInit(): void {
  }

  login(){
    if(this.username == "" || this.password == ""){
      this.message = "Nisu uneta sva polja!";
    }
    else{
      this.userService.login(this.username, this.password).subscribe((user:User)=>{

        sessionStorage.setItem('currlogin',JSON.stringify(user));
        if(user){
          if(user.status==1){
            if(user.type!=5){
              //this.router.navigate(['/clientpage']);
              //this.message ="ok";
              this.message ="Nepostojeci admin nalog!";
            }else if(user.type==5){
              this.router.navigate(['/adminpage']);
            }
          }else if(user.status==0){
            //alert("Vas zahtev za registraciju jos nije obradjen od strane administratora!");
            this.message ="Vas zahtev za registraciju jos nije obradjen od strane administratora!";
          }
        }
        else {
          //alert('Bad data');
          this.message = "Neispravno uneti podaci!";
        }
      })
    }
  }
}
