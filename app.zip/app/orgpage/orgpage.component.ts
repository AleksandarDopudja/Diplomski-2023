import { Component, OnInit, Renderer2 } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import mapboxgl from 'mapbox-gl';

@Component({
  selector: 'app-orgpage',
  templateUrl: './orgpage.component.html',
  styleUrls: ['./orgpage.component.css']
})
export class OrgpageComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Dostavljaci", "Majstori"];


  ngOnInit(): void {

    const link1 = document.createElement('link');
    link1.href = 'https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.css';
    link1.rel = 'stylesheet';
    document.head.appendChild(link1);

    const link2 = document.createElement('link');
    link2.href = 'https://cdn.jsdelivr.net/npm/vue-mapbox@latest/dist/vue-mapbox.css';
    link2.rel = 'stylesheet';
    document.head.appendChild(link2);

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status!=0 && w.type==3);
    });

    const map = new mapboxgl.Map({
      container: 'map-container',
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [20.452767, 44.815209],
      zoom: 12,
      accessToken:"pk.eyJ1IjoiZG9wMTExMSIsImEiOiJjbG10YmVqYzQwMXhmMnFvYzQ4eWJweDlqIn0.3_ZmWiQ63tfsejN2Ak4RPA"
    });

    const marker = new mapboxgl.Marker()
    .setLngLat([20.452767, 44.815209]) // Koordinate za neku ulicu u Beogradu
    .addTo(map);

    marker.getElement().addEventListener('click', () => {
      alert("Clicked");
    });

    const marker2 = new mapboxgl.Marker({color: "#FFFFFF"})
    .setLngLat([20.453202, 44.820069]) // Koordinate za neku ulicu u Beogradu
    .addTo(map);

    sessionStorage.setItem('currlocationdetails',JSON.stringify(null));

  }

  search(i){
    this.curr = i-1;
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type=== (this.curr+3));
  }

  
}
