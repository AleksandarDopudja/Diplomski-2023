import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Klijenti","Organizatori","Dostavljaci", "Majstori"];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status!=0 && w.type!=5 && w.type==1);
    });

  }

  search(i){
    this.curr = i-1;
    sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type!=5);
    this.listUsers = this.service.search(i, this.listUsers);
  }

}
