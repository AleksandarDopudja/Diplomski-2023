import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiorddetailsComponent } from './diorddetails.component';

describe('DiorddetailsComponent', () => {
  let component: DiorddetailsComponent;
  let fixture: ComponentFixture<DiorddetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DiorddetailsComponent]
    });
    fixture = TestBed.createComponent(DiorddetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
