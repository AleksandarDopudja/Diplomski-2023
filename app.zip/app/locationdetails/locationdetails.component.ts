import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Location } from '../models/location';
import { Req } from '../models/req';

@Component({
  selector: 'app-locationdetails',
  templateUrl: './locationdetails.component.html',
  styleUrls: ['./locationdetails.component.css']
})
export class LocationdetailsComponent implements OnInit {

  constructor(private router: Router, private service: UserserviceService) { }

  location: Location;
  users: User[] = [];

  reqsRent: Req[] = [];
  reqsBuy: Req[] = [];

  usersRent: User[] = [];
  usersBuy: User[] = [];

  ngOnInit(): void {
    this.location = JSON.parse(sessionStorage.getItem('currlocationdetails'));
    sessionStorage.setItem('currlocationdetails', JSON.stringify(this.location));
    

    var idRR = this.location.idRR;
    var idBR = this.location.idSR;

    this.service.getAllReqByIds(idRR).subscribe((reqs: Req[])=>{
      this.reqsRent = reqs;

      this.service.getAllReqByIds(idBR).subscribe((reqs: Req[])=>{
        this.reqsBuy = reqs;

        var rentidarr = this.reqsRent.map(req => req.idu);
        var buyidarr = this.reqsBuy.map(req => req.idu);

        this.service.getAllUsersByUNs(rentidarr).subscribe((users1: User[])=>{

          this.service.getAllUsersByUNs(buyidarr).subscribe((users2: User[])=>{

            this.usersRent = users1;
            this.usersBuy = users2;
          })
        })

      })
    });


  }
}
