import { Component, OnInit } from '@angular/core';
import { Machineunit } from '../models/machineunit';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Machine } from '../models/machine';
import { User } from '../models/user';
import { Location } from '../models/location';
import { MapOfPro } from '../models/mapofpro';
import { Product } from '../models/product';
import { Chart, registerables} from 'chart.js';
import { Sale } from '../models/sale';

@Component({
  selector: 'app-machineunitdetails',
  templateUrl: './machineunitdetails.component.html',
  styleUrls: ['./machineunitdetails.component.css']
})
export class MachineunitdetailsComponent implements OnInit {

  constructor(private service: UserserviceService){}

  machineunit: Machineunit[] = [];
  machine: Machine = null;
  user: User = null;
  location: Location = null;
  map: MapOfPro = null;

  prod: string[] = [];

  products: Product[] = [];

  con: number[] =[];

  ind: number = 0;

  randomColors: String[] = [];

  sale: Sale[] = [];

  salepro: Product[] = [];

  maxcap: number = 0;

  saleCountsByHour: number[]  =[];

  arr: any[] = [];

  mus: Machineunit = null;

  loginuser: User;

  ngOnInit(): void {
    
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.machine = JSON.parse(sessionStorage.getItem('currmachine'));
    this.machineunit = JSON.parse(sessionStorage.getItem('currmachineunits'));
    this.user = JSON.parse(sessionStorage.getItem('curruserdetails'));
    this.location = JSON.parse(sessionStorage.getItem('currlocationdetails'));
    this.mus = JSON.parse(sessionStorage.getItem('currmachineunit'));

    if(this.loginuser.type==1){
      for(let i =0; i< this.machineunit.length; i++){
        if(this.mus._id == this.machineunit[i]._id){
          this.con = this.machineunit[i].content;
          this.ind = i;
        }
      }
    }else{
      for(let i =0; i< this.machineunit.length; i++){
        if(this.machine.name == this.machineunit[i].type){
          this.con = this.machineunit[i].content;
          this.ind = i;
        }
      }
    }

    console.log("ALOOq")
    console.log(this.machineunit);

    console.log("ALOO")
    console.log(this.mus)
    console.log(this.machineunit[this.ind])

    this.service.getMap(this.machineunit[this.ind]._id).subscribe((map:MapOfPro[])=>{
      this.map = map[0];

      //console.log(this.map.map);
     
      for(let i = 0;i< this.map.map.length;i++){
        this.prod.push(this.map.map[i]);
      }

      //console.log(this.prod)
      this.service.getProductByNames(this.prod).subscribe((pro:Product[])=>{
        this.products = pro;

        //console.log(this.products)

        const sortedFirstList = this.products.sort((a, b) => {
          const aIndex = this.prod.indexOf(a.name);
          const bIndex = this.prod.indexOf(b.name);
          
          if (aIndex === -1) return 1;  // Ako a nije pronađen, stavi ga na kraj
          if (bIndex === -1) return -1; // Ako b nije pronađen, stavi ga na početak
        
          return aIndex - bIndex; // Sortiraj prema redosledu u drugoj listi
        });
        //console.log(sortedFirstList)

        this.products = sortedFirstList;

        this.randomColors = this.getRandomColors(this.products.length);

        if(this.products[0].type=="kafa"){
          this.maxcap = 50
        }else{
          this.maxcap = 100;
        }

        //console.log(this.maxcap); 

        this.createChart();

        //console.log(this.machineunit[this.ind]._id);

        this.service.getSaleForMachineUnit(this.machineunit[this.ind]._id).subscribe((sale:Sale[])=>{
          this.sale = sale;

          //console.log(sale);

          
            const productsInSale: Product[] = [];

            for (const saleItem of this.sale) {
            
              const product = this.products.find(product => product._id === saleItem.idpro);

              if (product) {
                productsInSale.push(product);
              }
            }

            this.saleCountsByHour = this.getSaleCountsByHour(this.sale);
            //console.log(this.saleCountsByHour)
          
            this.createLineChart();

            //console.log(productsInSale);

            productsInSale.sort((a, b) => a.name.localeCompare(b.name));

                if (productsInSale.length > 0) {
                  let ind = 0;
                  this.arr[ind] = { name: productsInSale[0].name, c: 1 };

                  for (let i = 1; i < productsInSale.length; i++) {
                    if (this.arr[ind] && this.arr[ind].name == productsInSale[i].name) {
                      this.arr[ind].c += 1;
                    } else {
                      ind++;
                      this.arr[ind] = { name: productsInSale[i].name, c: 1 };
                    }
                  }
                }

                //console.log(this.arr);           
            
            this.createPieChart();
        })
      });
    })


  }

  generateRandomColor(): string {
    const letters = '0123456789ABCDEF';
    let color = 'rgba(';
    for (let i = 0; i < 3; i++) {
      const randomValue = Math.floor(Math.random() * 256); // Generiše slučajnu vrednost od 0 do 255
      color += randomValue.toString();
      if (i < 2) {
        color += ', ';
      }
    }
    color += ', 0.5)';  // Dodajte transparentnost (alfa kanal)
    return color;
  }
  
  getRandomColors(n: number): string[] {
    const randomColors: string[] = [];
    for (let i = 0; i < n; i++) {
      const randomColor = this.generateRandomColor();
      randomColors.push(randomColor);
    }
    return randomColors;
  }

  createChart() {
    Chart.register(...registerables);
    const ctx = document.getElementById('myChart') as HTMLCanvasElement;
    const myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: this.products.map(pro=>pro.name),
        datasets: [{
          label:'',
          data: this.con,
          backgroundColor: this.randomColors as string[],
          borderColor: this.randomColors.map(color => color.replace('0.2', '1')) as string[],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            type: 'linear', 
            beginAtZero: true
          }
        }
      }
    });
  }

  getSaleCountsByHour(sales: Sale[]): number[] {
    const saleCountsByHour: number[] = Array(24).fill(0);

    sales.forEach(sale => {
      const d = new Date(sale.time);
      const hour = d.getHours()-2;

      //console.log(hour)
      
      if (hour >= 0 && hour < 24) {
        saleCountsByHour[hour-1]++;
        //console.log(saleCountsByHour)
      }
    });
  
    return saleCountsByHour;
  }

  createLineChart() {
    Chart.register(...registerables);
    const canvas: any = document.getElementById('line-chart');
    const ctx = canvas.getContext('2d');

    const arrayOfNumbers: string[] = Array.from({ length: 24 }, (_, index) => (index + 1).toString());
  
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: arrayOfNumbers,
        datasets: [{
          label: 'Prodaja/h',
          data: this.saleCountsByHour,
          borderColor: 'blue',  // Boja linije
          backgroundColor: 'rgba(0, 0, 255, 0.5)',  // Boja ispod linije
          borderWidth: 3,
          borderCapStyle: 'round',  // Zaobljavanje linije
          fill: true  // Popuni prostor ispod linije
        }]
      },
      options: {
        scales: {
          x: {
            beginAtZero: true
          },
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1 
            }  
          }
        }
      }
    });

  }

  createPieChart() {
    Chart.register(...registerables);

    const canvas: any = document.getElementById('PieChart');
    const ctx = canvas.getContext('2d');

    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: this.arr.map(pro=>pro.name),
        datasets: [{
          label: '',
          data: this.arr.map(pro=>pro.c),
          backgroundColor: this.randomColors as string[],
          borderColor: this.randomColors.map(color => color.replace('0.2', '1')) as string[],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Pie Chart Example'
          }
        }
      }
    });
  }

}
