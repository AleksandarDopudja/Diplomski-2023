import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientreqcardComponent } from './clientreqcard.component';

describe('ClientreqcardComponent', () => {
  let component: ClientreqcardComponent;
  let fixture: ComponentFixture<ClientreqcardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ClientreqcardComponent]
    });
    fixture = TestBed.createComponent(ClientreqcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
