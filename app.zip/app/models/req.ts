import { Location } from '../models/location';

export class Req{
    idu: string;
    machines:string[];
    status: number;
    type: number;
    date: Date;
    location: Location;
    _id:string;
}