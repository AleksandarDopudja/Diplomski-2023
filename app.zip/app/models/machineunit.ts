import { Machine } from "./machine";
import { Location } from "./location";

export class Machineunit{
    type: string;
    date: Date;
    price: number;
    content: number[];
    machine: Machine;
    location: Location;
    _id: string;
}