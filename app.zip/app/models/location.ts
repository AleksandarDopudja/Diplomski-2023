export class Location{
    x: number;
    y: number;
    name: string;
    addr: string;
    idRR: string[];
    idSR: string[];
    demand: number;
    _id:string;
}