export class DisOrder{
    dos1: string;
    dos2: string;
    date: Date;
    sec: Array<String>;
    txt: Array<String>;
    status: string;
    orgusername: string;
    _id:string;
}