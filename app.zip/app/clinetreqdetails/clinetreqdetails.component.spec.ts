import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinetreqdetailsComponent } from './clinetreqdetails.component';

describe('ClinetreqdetailsComponent', () => {
  let component: ClinetreqdetailsComponent;
  let fixture: ComponentFixture<ClinetreqdetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ClinetreqdetailsComponent]
    });
    fixture = TestBed.createComponent(ClinetreqdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
