import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';
import { UserserviceService } from '../servicesforsys/userservice.service';


@Component({
  selector: 'app-storagecard',
  templateUrl: './storagecard.component.html',
  styleUrls: ['./storagecard.component.css']
})
export class StoragecardComponent implements OnInit {

  constructor(private router: Router, private service: UserserviceService) { }

  loginuser: User;

  @Input() storage: Storage;

  quantity: number = 0;

  perc: number = 0;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getTotalStockQuant(this.storage['_id']).subscribe((resp)=>{
      this.quantity = resp['totalQuantity'];

      this.perc = this.quantity/this.storage["space"]*100;
    })
  }

  goDetails(){
    sessionStorage.setItem('currstoragedetails', JSON.stringify(this.storage));
    this.router.navigate(['../storagedetails']);
  }
}
