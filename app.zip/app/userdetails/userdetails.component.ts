import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Location } from '../models/location';
import { Req } from '../models/req';
import { Machineunit } from '../models/machineunit';
import { Machine } from '../models/machine';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;

  user: User;

  commclients: User[] = [];

  clientsusernames: string[] = [];

  location: Location = null;

  req: Req = null;

  machineunits: Machineunit[] = [];
  machines: Machine[] = [];

  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.user = JSON.parse(sessionStorage.getItem('curruserdetails'));

    this.service.getUsers().subscribe((users: User[]) => {
      this.commclients = users;
      
    });


    this.location = JSON.parse(sessionStorage.getItem('currlocationdetails'));

    if(this.location!=null){
      this.service.getReq(this.location.idRR, this.user.username).subscribe((req: Req[]) => {
        this.req = req[0];

        this.service.getAllMachineUnitsByIds(this.req.machines).subscribe((machineunits: Machineunit[]) => {
          this.machineunits = machineunits;

          sessionStorage.setItem('currmachineunits',JSON.stringify(machineunits));
          
          const idArray = this.machineunits.map(mu => mu.type);

          this.service.getAllMachinesByIds(idArray).subscribe((machines: Machine[]) => {
            this.machines = machines;
          });
          
        });
        
      });
    }else if(this.loginuser.type==1 || this.loginuser.type==5){
      
      this.service.getReqByUsername(this.loginuser.username).subscribe((req: Req[]) => {
        req = req.filter(r => r.status != 0);

        for(let r of req){
          this.service.getAllLocationsForMUID(r._id).subscribe((loc: Location) => {
             r.location = loc;
          });
        }
        
        let ids = [];
        for(let i=0;i< req.length; i++){
          ids.push(...req[i].machines)
        }

        this.service.getAllMachineUnitsByIds(ids).subscribe((machineunits: Machineunit[]) => {
          this.machineunits = machineunits;

          for(let r of req){
            for(let m of r.machines){
              this.machineunits.find(item => item._id === m).location = r.location;
            }
          }

         
             const idArray = this.machineunits.map(mu => mu.type);
            
             const uniqueArray = [...new Set(idArray)];

            this.service.getAllMachinesByIds(uniqueArray).subscribe((machines: Machine[]) => {
              this.machines = machines;

              for(let m of this.machineunits){
                m.machine = this.machines.find(item => item.name === m.type);
                m.machine.location = m.location;
                console.log(m.machine)
                console.log(m.machine.location)

                
              }

              sessionStorage.setItem('currmachineunits',JSON.stringify(machineunits));
              
            });
          
          
        });
        
        
      });
    }else{
      
    }
  }

  request(){
    this.router.navigate(['/jobrequest']);
  }

  accept(){
    this.service.setStatus(this.user.username, 1).subscribe(()=>{ 
      this.router.navigate(['/adminrequests']);
    })
  }

  dismiss(){
    this.service.setStatus(this.user.username, 4).subscribe(()=>{ 
      this.router.navigate(['/adminrequests']);
    })
  }

  deleteUser(){
    this.service.deleteUser(this.user.username).subscribe(()=>{ 
      this.router.navigate(['/adminpage']);
    })
  }

  


}
