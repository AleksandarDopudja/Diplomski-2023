import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NavbarComponent } from './navbar/navbar.component';
import { ProductsComponent } from './products/products.component';
import { ServicesComponent } from './services/services.component';
import { FooterComponent } from './footer/footer.component';
import { MachinesComponent } from './machines/machines.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UsercardComponent } from './usercard/usercard.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { AdduserComponent } from './adduser/adduser.component';
import { AdminrequestsComponent } from './adminrequests/adminrequests.component';
import { AllstoragesComponent } from './allstorages/allstorages.component';
import { StoragecardComponent } from './storagecard/storagecard.component';
import { StoragedetailsComponent } from './storagedetails/storagedetails.component';
import { ProductcardComponent } from './productcard/productcard.component';
import { OrgpageComponent } from './orgpage/orgpage.component';
import { AlllocationsComponent } from './alllocations/alllocations.component';
import { LocationcardComponent } from './locationcard/locationcard.component';
import { LocationdetailsComponent } from './locationdetails/locationdetails.component';
import { MachineunitcardComponent } from './machineunitcard/machineunitcard.component';
import { CarcardComponent } from './carcard/carcard.component';
import { GarageComponent } from './garage/garage.component';
import { DistributionComponent } from './distribution/distribution.component';
import { MachineunitdetailsComponent } from './machineunitdetails/machineunitdetails.component';
import { UserpageComponent } from './userpage/userpage.component';
import { DisordsComponent } from './disords/disords.component';
import { DisordcardComponent } from './disordcard/disordcard.component';
import { DiorddetailsComponent } from './diorddetails/diorddetails.component';
import { ClientpageComponent } from './clientpage/clientpage.component';
import { ClientreqcardComponent } from './clientreqcard/clientreqcard.component';
import { ClinetreqdetailsComponent } from './clinetreqdetails/clinetreqdetails.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomepageComponent,
    NavbarComponent,
    ProductsComponent,
    ServicesComponent,
    FooterComponent,
    MachinesComponent,
    LoginComponent,
    RegisterComponent,
    LoginadminComponent,
    AdminpageComponent,
    AdminloginComponent,
    UsercardComponent,
    UserdetailsComponent,
    AdduserComponent,
    AdminrequestsComponent,
    AllstoragesComponent,
    StoragecardComponent,
    StoragedetailsComponent,
    ProductcardComponent,
    OrgpageComponent,
    AlllocationsComponent,
    LocationcardComponent,
    LocationdetailsComponent,
    MachineunitcardComponent,
    CarcardComponent,
    GarageComponent,
    DistributionComponent,
    MachineunitdetailsComponent,
    UserpageComponent,
    DisordsComponent,
    DisordcardComponent,
    DiorddetailsComponent,
    ClientpageComponent,
    ClientreqcardComponent,
    ClinetreqdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
