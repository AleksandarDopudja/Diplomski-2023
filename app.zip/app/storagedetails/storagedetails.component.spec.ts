import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoragedetailsComponent } from './storagedetails.component';

describe('StoragedetailsComponent', () => {
  let component: StoragedetailsComponent;
  let fixture: ComponentFixture<StoragedetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoragedetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StoragedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
