import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllstoragesComponent } from './allstorages.component';

describe('AllstoragesComponent', () => {
  let component: AllstoragesComponent;
  let fixture: ComponentFixture<AllstoragesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllstoragesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllstoragesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
