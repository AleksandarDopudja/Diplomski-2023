import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Location } from '../models/location';

@Component({
  selector: 'app-locationcard',
  templateUrl: './locationcard.component.html',
  styleUrls: ['./locationcard.component.css']
})
export class LocationcardComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() location: Location;

  goDetails(){
    sessionStorage.setItem('currlocationdetails', JSON.stringify(this.location));
    this.router.navigate(['../locationdetails']);
  }
}
