import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Machine } from '../models/machine';
import { Machineunit } from '../models/machineunit';

@Component({
  selector: 'app-machineunitcard',
  templateUrl: './machineunitcard.component.html',
  styleUrls: ['./machineunitcard.component.css']
})
export class MachineunitcardComponent implements OnInit  {

  constructor(private router: Router) { }

  loginuser: User;
  user: User;
  mus: Machineunit[] = [];

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.user = JSON.parse(sessionStorage.getItem('curruserdetails'));
    this.mus = JSON.parse(sessionStorage.getItem('currmachineunits'));
    if(this.loginuser.type!=1)this.mus=null;
    //console.log("AAAAA")
    //console.log(this.mus[this.ind].location[0].name);
  }

  @Input() machine: Machine;
  @Input() ind: number;

  goDetails(){
    
    sessionStorage.setItem('currmachine', JSON.stringify(this.machine));
    if(this.loginuser.type==1){
      sessionStorage.setItem('currmachineunit', JSON.stringify(this.mus[this.ind]));
      sessionStorage.setItem('currlocationdetails', JSON.stringify(this.mus[this.ind].location[0]));
    }

    this.router.navigate(['../machineunitdetails']);
  }
}
