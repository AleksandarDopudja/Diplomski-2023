import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineunitcardComponent } from './machineunitcard.component';

describe('MachineunitcardComponent', () => {
  let component: MachineunitcardComponent;
  let fixture: ComponentFixture<MachineunitcardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MachineunitcardComponent]
    });
    fixture = TestBed.createComponent(MachineunitcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
