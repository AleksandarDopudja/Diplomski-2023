import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { Machine } from '../models/machine';
import { User } from '../models/user';

@Component({
  selector: 'app-machines',
  templateUrl: './machines.component.html',
  styleUrls: ['./machines.component.css']
})
export class MachinesComponent implements OnInit {

  constructor( private service: UserserviceService, private router: Router) { }

  machines: Machine[] = [];

  loginuser: User = null;

  cvan: number;

  msg: string = "";

  addres: string = "";

  si: number = -1;

  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getAllMachines().subscribe((machines: Machine[])=>{
      this.machines = machines;
    });
  }

  buy(i){

    this.service.insertClientReq(this.loginuser.username, "buy", this.cvan, this.machines[i].name, this.addres).subscribe((resp)=>{
      this.si = i;
      this.msg = "Zahtev za kupovinu uspesno poslat!"
      this.cvan = null;
      this.addres  = null;
    });
  }

  rent(i){
    this.si = i;
    this.msg = "Zahtev za iznajmljivanje uspesno poslat!"

    this.service.insertClientReq(this.loginuser.username, "rent", this.cvan, this.machines[i].name, this.addres).subscribe((resp)=>{
      this.si = i;
      this.msg = "Zahtev za kupovinu uspesno poslat!"
      this.cvan = null;
      this.addres  = null;
    });
  }

}
