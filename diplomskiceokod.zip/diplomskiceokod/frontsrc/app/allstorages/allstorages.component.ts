import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allstorages',
  templateUrl: './allstorages.component.html',
  styleUrls: ['./allstorages.component.css']
})
export class AllstoragesComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allStorages: Storage[] = [];
  searchname: string = "";
  types: string[] = ["Registracija","Prodaja","Izdavanje", "Nabavka"];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getAllStorages().subscribe((storages: Storage[])=>{
      this.allStorages = storages;
    });

  }

  search(i){
    //this.curr = i-1;
    //sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    //this.listUsers = this.allUsers.filter(w=>w.status==0 && w.type!=5);
  }


}
