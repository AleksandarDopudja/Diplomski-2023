import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../models/car';
import { User } from '../models/user';

@Component({
  selector: 'app-carcard',
  templateUrl: './carcard.component.html',
  styleUrls: ['./carcard.component.css']
})
export class CarcardComponent implements OnInit{

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() car: Car;

  goDetails(){
    //sessionStorage.setItem('curruserdetails', JSON.stringify(this.user));
    //this.router.navigate(['../userdetails']);
  }
}
