import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisordsComponent } from './disords.component';

describe('DisordsComponent', () => {
  let component: DisordsComponent;
  let fixture: ComponentFixture<DisordsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DisordsComponent]
    });
    fixture = TestBed.createComponent(DisordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
