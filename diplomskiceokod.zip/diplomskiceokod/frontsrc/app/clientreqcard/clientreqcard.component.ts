import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { ClientReq } from '../models/clientreq';

@Component({
  selector: 'app-clientreqcard',
  templateUrl: './clientreqcard.component.html',
  styleUrls: ['./clientreqcard.component.css']
})
export class ClientreqcardComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() clientreq: ClientReq;

  goDetails(){
    sessionStorage.setItem('currclientreq', JSON.stringify(this.clientreq));
    this.router.navigate(['../clientreqdetails']);
  }
}
