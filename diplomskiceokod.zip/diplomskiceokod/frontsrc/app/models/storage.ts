export class Storage{
    name: string;
    location: string;
    mail: string;
    tell: string;
    space: number;
    _id:string;
}