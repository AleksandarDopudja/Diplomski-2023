export class Car{
    reg: number;
    model: string;
    crew: string[];
    capcrew: number;
    capstorage: number;
    foto:string;
    _id:string;
}