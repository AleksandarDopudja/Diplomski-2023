import { Location } from "./location";

export class Machine{
    name: string;
    about: string;
    h: number;
    w: number;
    d: number;
    weight: number;
    foto: string;
    price: number;
    cap: number;
    location: Location;
    _id: string;
}