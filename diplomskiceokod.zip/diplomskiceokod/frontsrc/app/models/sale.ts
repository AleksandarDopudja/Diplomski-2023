export class Sale{
    idmu: string;
    idpro: string;
    time: Date;
    _id:string;
}