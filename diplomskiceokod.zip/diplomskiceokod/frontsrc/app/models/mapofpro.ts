export class MapOfPro{
    idmu: string;
    map: string[];
    _id: string;
}