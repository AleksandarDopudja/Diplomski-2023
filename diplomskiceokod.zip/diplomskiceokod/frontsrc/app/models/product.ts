export class Product{
    name: string;
    company: string;
    inprice: number;
    type: string;
    weight: string;
    foto: string;
    quantity: number;
    _id: string;
}