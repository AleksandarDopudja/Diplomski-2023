
export class ClientReq{
    clientusername: string;
    type: string;
    cvan: number;
    mtype: string;
    addres: string;
    _id:string;
}