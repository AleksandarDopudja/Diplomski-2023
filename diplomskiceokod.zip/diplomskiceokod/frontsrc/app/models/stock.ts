export class Stock{
    idp: string;
    ids:string;
    quantity: number;
    _id:string;
}