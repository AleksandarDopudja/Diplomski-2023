import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisordcardComponent } from './disordcard.component';

describe('DisordcardComponent', () => {
  let component: DisordcardComponent;
  let fixture: ComponentFixture<DisordcardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DisordcardComponent]
    });
    fixture = TestBed.createComponent(DisordcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
