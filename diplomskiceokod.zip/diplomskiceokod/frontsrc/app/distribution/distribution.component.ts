import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Location } from '../models/location';
import { Req } from '../models/req';
import mapboxgl from 'mapbox-gl';
import * as polyline from '@mapbox/polyline';
import { Machineunit } from '../models/machineunit';
import { MapOfPro } from '../models/mapofpro';


@Component({
  selector: 'app-distribution',
  templateUrl: './distribution.component.html',
  styleUrls: ['./distribution.component.css']
})
export class DistributionComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";

  allloactions: Location[] = [];

  markers: mapboxgl.Marker[]=[];

  lastclkmarker: number = -1;

  currlocations: Location[] = [];

  textMarkers: mapboxgl.Marker[] = [];

  globalIndex: number = 0;

  map: mapboxgl.Map;

  machineUnites: Machineunit[] = [];

  locationsForPath: Location[] = [];

  cargocap: number = 600; //600

  sec: any[][];

  sectxt: string[] = [];

  selectedValue: string = "";

  selectedValue2: string = "";

  dt: Date;


  changeMarkerColor(index: number, c: string) {
    const pathElement = this.markers[index].getElement().querySelector('path');
    pathElement.style.fill = c;  // Postavite boju fill-a na crvenu
  }

  ngOnInit(): void {

    const link1 = document.createElement('link');
    link1.href = 'https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.css';
    link1.rel = 'stylesheet';
    document.head.appendChild(link1);

    const link2 = document.createElement('link');
    link2.href = 'https://cdn.jsdelivr.net/npm/vue-mapbox@latest/dist/vue-mapbox.css';
    link2.rel = 'stylesheet';
    document.head.appendChild(link2);

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status!=0 && w.type==3);
    });

    this.service.getAllLocations().subscribe((locations: Location[])=>{
      this.allloactions = locations;

       this.map = new mapboxgl.Map({
        container: 'map-container',
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [20.452767, 44.815209],
        zoom: 12,
        accessToken:"pk.eyJ1IjoiZG9wMTExMSIsImEiOiJjbG10YmVqYzQwMXhmMnFvYzQ4eWJweDlqIn0.3_ZmWiQ63tfsejN2Ak4RPA"
      });

      this.map.on('click', function(e) {
        //this.currlocation = null;
      });

      this.allloactions.forEach((location, index) => {
        const marker = new mapboxgl.Marker({color:'blue'})
          .setLngLat([location['y'], location['x']])
          .addTo(this.map);
  
        this.markers.push(marker);
  
        // Dodajemo klasu na marker
        const markerElement = marker.getElement();

        markerElement.addEventListener('click', () => {
          // Dodajte svoju logiku za klik na marker
          //if(this.lastclkmarker==index)return;

          this.changeMarkerColor(index, "red");

          // if(this.lastclkmarker != -1){
          //   this.changeMarkerColor(this.lastclkmarker, "blue");
          // }
          

          this.lastclkmarker = index;
          //alert(index);
          if(this.isLocationInList(this.allloactions[index]["name"])){
            this.createText(this.markers[index], this.map, this.globalIndex++);
            this.currlocations.push(this.allloactions[index]);
          }else{
            
            const ordindex = this.currlocations.findIndex((location) => location["name"] === this.allloactions[index]["name"]);
            //alert(index);
            //alert(this.globalIndex);
            //console.log(this.markers[i].getLngLat())
            if(ordindex==this.globalIndex-1){
             
              this.changeMarkerColor(index, "blue");
             
              this.removeTextMarker(ordindex);

              this.globalIndex--;
            }else{
      
            }
          }
        });
      });

      //44.821441, 20.535749 magacin Bg
      const marker = new mapboxgl.Marker({color:'lightgreen'})
          .setLngLat([20.535749, 44.821441])
          .addTo(this.map);
         

    })

    // const marker = new mapboxgl.Marker()
    // .setLngLat([20.452767, 44.815209]) // Koordinate za neku ulicu u Beogradu
    // .addTo(map);

    // marker.getElement().addEventListener('click', () => {
    //   alert("Clicked");
    // });

    // const marker2 = new mapboxgl.Marker({color: "#FFFFFF"})
    // .setLngLat([20.453202, 44.820069]) // Koordinate za neku ulicu u Beogradu
    // .addTo(map);

    //alert(this.allloactions.length);

  }


  createText(marker, map, txt){

    const LngLat = marker.getLngLat();
    
    const markerElement = document.createElement('div');
    markerElement.style.fontSize = '12px';
    markerElement.style.fontWeight = 'bold';
    markerElement.style.color = 'blue';
    markerElement.textContent = txt+1;

    const newLngLat = { lng: LngLat.lng, lat: LngLat.lat+0.0025 };

    const mar = new mapboxgl.Marker(markerElement)
      .setLngLat(newLngLat)
      .addTo(map);

    this.textMarkers.push(mar);
  }

  removeTextMarker(index) {
    // Iterirajte kroz niz text markera
  
      // Uporedite koordinate
     
        // Uklonite marker sa mape
        
        this.textMarkers[index].remove();
  
        // Uklonite marker iz niza
        
        this.textMarkers.splice(index, 1);
        this.currlocations.splice(index, 1);
        


        this.globalIndex--;
  
        return; // Izlaz iz funkcije nakon uklanjanja markera
      

  }

  search(i){
    this.curr = i-1;
    //sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type=== (this.curr+3));
  }

  paintmarker(i){

    //if(this.lastclkmarker==i)return;

    //this.changeMarkerColor(i, "red");

    // if(this.lastclkmarker != -1){
    //   this.changeMarkerColor(this.lastclkmarker, "blue");
    // }
   
    if(this.isLocationInList(this.allloactions[i].name)){
      this.lastclkmarker = i;
      this.changeMarkerColor(i, "red");
      this.createText(this.markers[i], this.map, this.globalIndex++);
      this.currlocations.push(this.allloactions[i]);
     
    }else{
      const index = this.allloactions.findIndex((location) => location["name"] === this.allloactions[i]["name"]);
      const ordindex = this.currlocations.findIndex((location) => location["name"] === this.allloactions[i]["name"]);
      //alert(index);
      //alert(this.globalIndex);
      //console.log(this.markers[i].getLngLat())
      if(ordindex==this.globalIndex-1){
       
        this.changeMarkerColor(i, "blue");
       
        this.removeTextMarker(ordindex);
      }else{

      }
    }
  }

  isLocationInList(name): boolean {

    for(let i = 0; i< this.currlocations.length; i++){
      if(this.currlocations[i]['name']==name) return false;
    }
    return true;
  }

  mUnitesMaps : MapOfPro[] = [];

  mapProducts: Map<string, number>;

  mapProductsTotal: Map<string, number>;

  req: Req[] = [];

  mids: string[] =[];

  txt: string[] = [];

  click: boolean = false;

  calculate(){

    this.txt = [];

    if(this.currlocations.length==0) this.currlocations = this.allloactions.slice();
    //console.log(this.currlocations)

    this.mapProducts = new Map();

    this.mapProductsTotal = new Map();

    let reqids: string[] = [];

    for(let i=0;i< this.currlocations.length; i++){

      for(let j=0;j<this.currlocations[i]['idRR'].length;j++){
        reqids.push(this.currlocations[i]['idRR'][j]);
      }

      for(let j=0;j<this.currlocations[i]['idSR'].length;j++){
        reqids.push(this.currlocations[i]['idSR'][j]);
      }
    }

    this.service.getAllReqByIds(reqids).subscribe((reqq: Req[])=>{
      this.req = reqq;
      
      for(let i=0;i< this.req.length; i++){

        for(let j=0;j<this.req[i]['machines'].length;j++){
          this.mids.push(this.req[i]['machines'][j]);
        }
        
      }

      this.service.getAllMachineUnitsByIds(this.mids).subscribe((m: Machineunit[])=>{
        this.machineUnites = m;

        //console.log(this.machineUnites)
        
        this.service.getAllMapsByIds(this.mids).subscribe((m: MapOfPro[])=>{
          this.mUnitesMaps = m;
          //console.log("MAPE za aparate:")
          //console.log(this.mUnitesMaps);

          for(let i =0;i<this.machineUnites.length;i++){
            this.calculateForMU(this.machineUnites[i]);
          }
          this.mapProducts.forEach((value, key) => {
            this.mapProductsTotal.set(key, value);
          });
          
          //console.log(this.mapProducts);
        })

    
        for(let i=0;i<this.currlocations.length;i++){
           for(let j=0;j< this.currlocations[i]['idRR'].length;j++){
              const r = this.req.find(req => req['_id'] === this.currlocations[i]['idRR'][j]);
              //console.log(r);
              if(r==null) continue;

              let suma = 0;
              for(let k=0;k< r['machines'].length;k++){
                const m = this.machineUnites.find(mach=> mach['_id'] === r['machines'][k])
                if(m==null) continue;

                suma+=m['content'].reduce((sum, val)=>sum+val, 0);
              }
              this.currlocations[i]['demand'] = suma;
           }
        }
        
        console.log(this.currlocations);


        const startLocation = new Location();
        startLocation.x = 44.815209;
        startLocation.y = 20.535749;
        startLocation.name ="Magacin Beograd 1";
        startLocation.addr = "Visnjicka 273a, Beograd";
        startLocation.demand = 0;

        this.locationsForPath = this.currlocations.slice();
        this.locationsForPath.unshift(startLocation);

        //console.log(this.locationsForPath);

        const path = this.twoOpt(this.locationsForPath);
        //this.currlocations = path;

        console.log(path);
       
        this.globalIndex=0;
        for(let i =1;i<path.length;i++){
          const ordtxtindex = this.textMarkers.findIndex((m) => (m.getLngLat().lat-0.0025) === path[i].x && m.getLngLat().lng === path[i].y);
          if(ordtxtindex!=-1){
            this.textMarkers[ordtxtindex].remove();
            this.textMarkers.splice(ordtxtindex, 1);
          }

          const ordindex = this.markers.findIndex((m) => m.getLngLat().lat === path[i].x && m.getLngLat().lng === path[i].y);
          //console.log(ordindex)
          
          this.changeMarkerColor(ordindex, "red");
          this.createText(this.markers[ordindex], this.map, this.globalIndex++);
        }

        let sumcargo = this.cargocap;
        var finalpath = path.slice();
        for(let i = 1, j=0;i<path.length;i++){
          if(sumcargo - path[i].demand < 0){
            //console.log(this.cargocap - sumcargo)
            finalpath.splice(i+j , 0, path[0]);
            j++;
            sumcargo = this.cargocap - path[i].demand;
          }else{
            sumcargo-=path[i].demand;
          }
        }
        finalpath.push(path[0]);
        this.currlocations = finalpath;
        //console.log(finalpath)

        this.sec = this.splitList(finalpath, path[0]);

        console.log(this.sec);

        //this.calculateCargoPerDrive();
      

      });

    });
  }

  calculateForMU(mu){
    //console.log("fija")
    const map = this.mUnitesMaps.find(item => item.idmu === mu._id);

    //console.log(mu['content'].length)

    for (let i = 0; i < mu['content'].length; i++) {
      const cap = 50;
      const key = map['map'][i];
      const currentValue = this.mapProducts.get(key) || 0;
      this.mapProducts.set(key, (currentValue + (cap - mu['content'][i])));
    }
  }

  twoOpt(path: Location[]): Location[] {
    const improve = true;
    let bestPath = path;
    let improved = true;

    while (improved) {
        improved = false;
        for (let i = 1; i < bestPath.length - 1; i++) {
            for (let j = i + 1; j < bestPath.length; j++) {
                if (j - i == 1) continue;  
                const newPath = this.twoOptSwap(bestPath, i, j);
                const newDistance = this.calculateTotalDistance(newPath);
                const oldDistance = this.calculateTotalDistance(bestPath);

                if (newDistance < oldDistance) {
                    bestPath = newPath;
                    improved = true;
                }
            }
        }
    }

    return bestPath;
  }

twoOptSwap(path: Location[], i: number, j: number): Location[] {
    const newPath = [...path];
    while (i < j) {
        const temp = newPath[i];
        newPath[i] = newPath[j];
        newPath[j] = temp;
        i++;
        j--;
    }
    return newPath;
}

calculateTotalDistance(path: Location[]): number {
    let totalDistance = 0;
    let cargo = this.cargocap;
    for (let i = 0; i < path.length - 1; i++) {
      if(cargo-path[i+1].demand<0){
        cargo = this.cargocap;
        totalDistance += this.calculateDistance(path[i], path[0]);
        totalDistance += this.calculateDistance(path[0], path[i + 1]);
      }
      else{
        cargo-=path[i+1].demand;
        totalDistance += this.calculateDistance(path[i], path[i + 1]);
      }
        
    }
    totalDistance += this.calculateDistance(path[path.length - 1], path[0]); 
    return totalDistance;
}

  calculateCargoDemand(locations: Location[]): number[] {
    
    const sortedLocations = locations.slice().sort((a, b) => a['idRR'].length - b['idRR'].length);
  
    // Calculate cargo demand based on the position in the sorted array
    return sortedLocations.map((location, index) => {
      // For simplicity, assuming the index represents cargo demand
      return index;
    });
  }

  calculateDistance(location1: Location, location2: Location): number {
    const dx = location1['x'] - location2['x'];
    const dy = location1['y'] - location2['y'];
    return Math.sqrt(dx * dx + dy * dy);
  }

  // Funkcija koja izračunava ukupnu količinu robe na putanji
  calculateTotalDemand(path: Location[]): number {
    return path.reduce((totalDemand, location) => totalDemand + location['demand'], 0);
  }

  // calculateTotalDistance(path: Location[]): number {
  //   let totalDistance = 0;
  //   for (let i = 0; i < path.length - 1; i++) {
  //     totalDistance += this.calculateDistance(path[i], path[i + 1]);
  //   }
  //   return totalDistance;
  // }

  splitList(list: any[], separator: any): any[][] {
    const result: any[][] = [];
    let currentSublist: any[] = [];
  
    for (const item of list) {
      if (item === separator) {
        // Dodaj trenutnu podlistu u rezultat i resetuj je
        if (currentSublist.length > 0) {
          result.push(currentSublist);
          currentSublist = [];
        }
      } else {
        // Dodaj element u trenutnu podlistu
        currentSublist.push(item);
      }
    }
  
    // Dodaj poslednju podlistu u rezultat
    if (currentSublist.length > 0) {
      result.push(currentSublist);
    }
  
    return result;
  }

  calculateCargoPerDrive(){

    //alert(this.cargocap)

    //console.log("SEC")
    //console.log(this.sec)
    //console.log(this.req)
    
    for(let i=0;i<this.sec.length;i++){
      let idrs = [];
      this.mapProducts = new Map();
      for(let j=0;j<this.sec[i].length;j++){
        let l = this.sec[i][j];
        //console.log(l)

        for(let k=0;k<l['idRR'].length;k++){
          idrs.push(l['idRR'][k]);
        }

        for(let k=0;k<l['idSR'].length;k++){
          idrs.push(l['idSR'][k]);
        }


        for(let k=0;k<idrs.length;k++){
          let r = this.req.find(rq=> rq._id == idrs[k] );
          //console.log(r)

          for(let q=0;q<r.machines.length;q++){
            
            let mu = this.machineUnites.find(m=> m._id==r.machines[q]);
            //console.log(mu)
            //console.log(this.mUnitesMaps)
            this.calculateForMU(mu);
          }
        }
        idrs = [];
        //let mcop = new Map();
        // this.mapProducts.forEach((value, key) => {
        //   mcop.set(key, value);
        // });
        // console.log(mcop);
        
      }
      //console.log(idrs);
      this.txt[i] = this.formatMap((this.mapProducts));
      //console.log(this.mapProducts)
      
    }
    console.log(this.txt);
  }

  formatMap(map: Map<any, any>): string {
    let result = '';
    for (const [key, value] of map) {
      result += `${key}: ${value}\n`;
    }
    return result;
  }

  send(){
    //alert(this.dt)

    //console.log(this.sec);

    //console.log("STRING");
    for(let i = 0;i<this.sec.length;i++){
      let str = "";
      for(let j=0;j<this.sec[i].length;j++){
        str+=((j+1)+" : "+this.sec[i][j]['name']+", "+this.sec[i][j]['addr'] + '\n');
        //console.log(str);
      }
      this.sectxt.push(str);
    }

    this.service.insertOrderReq(this.selectedValue, this.selectedValue2, this.dt, this.sectxt, this.txt).subscribe((resp)=>{
      console.log(resp['message']);
    })


    this.currlocations=[]; 
    this.txt = [];
    this.mapProductsTotal.clear();

    this.globalIndex=0;
    for(let i =0 ; i<this.textMarkers.length;i++){
      this.textMarkers[i].remove();
    }
    for(let i =0 ; i<this.markers.length;i++){
      this.changeMarkerColor(i,"blue");
    }

    this.dt = null;
    this.selectedValue = "";
    this.selectedValue2 = "";

    
    console.log(this.sectxt);

  }

}
