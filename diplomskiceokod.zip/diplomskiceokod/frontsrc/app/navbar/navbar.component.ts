import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  logoff(){
    sessionStorage.setItem('currlogin', null);
    this.router.navigate(['']);
  }

}
