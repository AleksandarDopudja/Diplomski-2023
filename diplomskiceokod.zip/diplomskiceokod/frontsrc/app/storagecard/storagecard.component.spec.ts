import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoragecardComponent } from './storagecard.component';

describe('StoragecardComponent', () => {
  let component: StoragecardComponent;
  let fixture: ComponentFixture<StoragecardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoragecardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StoragecardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
