import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { Stock } from '../models/stock';
import { Product } from '../models/product';

@Component({
  selector: 'app-storagedetails',
  templateUrl: './storagedetails.component.html',
  styleUrls: ['./storagedetails.component.css']
})
export class StoragedetailsComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  currStorage: Storage;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["grickalice","pica","kafa"];

  allStock: Stock[] = [];
  

  allProducts: Product[] = [];
  listProducts: Product[] = [];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.currStorage = JSON.parse(sessionStorage.getItem('currstoragedetails'));

    this.service.getStockFromStorage(this.currStorage['_id']).subscribe((stock: Stock[])=>{
      this.allStock = stock;
      const idpArray: string[] = this.allStock.map((stockItem: Stock) => stockItem.idp);
      
      this.service.getProductsFromStorage(idpArray).subscribe((products: Product[])=>{
        this.allProducts = products;


        this.allProducts = this.allProducts.map(product => {
          const correspondingStockItem = this.allStock.find(stockItem => stockItem.idp === product._id);
          if (correspondingStockItem) {
            product.quantity = correspondingStockItem.quantity;
          }
          return product;
        });

        this.listProducts = products.filter(w=>w.type==="grickalice");
      });
    });

  }

  search(i){
    this.curr = i-1;
    sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    
    this.listProducts = this.allProducts.filter(w=>w.type===this.types[this.curr]);
  }

}
