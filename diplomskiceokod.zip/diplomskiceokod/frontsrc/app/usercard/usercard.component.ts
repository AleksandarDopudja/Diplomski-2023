import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-usercard',
  templateUrl: './usercard.component.html',
  styleUrls: ['./usercard.component.css']
})
export class UsercardComponent implements OnInit {

  constructor(private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @Input() user: User;

  goDetails(){
    sessionStorage.setItem('curruserdetails', JSON.stringify(this.user));
    this.router.navigate(['../userdetails']);
  }

}
