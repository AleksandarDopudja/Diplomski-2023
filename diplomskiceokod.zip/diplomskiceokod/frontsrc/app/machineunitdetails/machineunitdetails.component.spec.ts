import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineunitdetailsComponent } from './machineunitdetails.component';

describe('MachineunitdetailsComponent', () => {
  let component: MachineunitdetailsComponent;
  let fixture: ComponentFixture<MachineunitdetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MachineunitdetailsComponent]
    });
    fixture = TestBed.createComponent(MachineunitdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
