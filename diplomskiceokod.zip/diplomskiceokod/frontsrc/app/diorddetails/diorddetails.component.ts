import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { DisOrder } from '../models/disorder';
import { UserserviceService } from '../servicesforsys/userservice.service';


@Component({
  selector: 'app-diorddetails',
  templateUrl: './diorddetails.component.html',
  styleUrls: ['./diorddetails.component.css']
})
export class DiorddetailsComponent implements OnInit {

  constructor(private router: Router, private service: UserserviceService) { }

  loginuser: User;
  disord: DisOrder;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.disord = JSON.parse(sessionStorage.getItem('disorddetails'));
    console.log(this.disord);
  }

  status(){

    this.service.updateStatusDisOrder(this.disord._id, "neaktivan").subscribe((resp)=>{
      alert(resp['message'])
      this.router.navigate(['../disorder']);
    })
  }

}
