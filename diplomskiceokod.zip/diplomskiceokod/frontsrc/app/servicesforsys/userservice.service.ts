import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  login(username, password){
    
    const data={
      username: username,
      password: password
    }

    return this.http.post(`${this.url}/user/login`, data);
  }

  register(firstname, lastname, username, password, tell, mail, foto, type, agencyname, country, city, street, mb){

    const data={
      firstname: firstname,
      lastname: lastname,
      username: username,
      password: password,
      tell: tell,
      mail: mail,
      foto: foto,
      type: type,
      agencyname: agencyname,
      country: country,
      city: city,
      street: street,
      mb: mb
    }

    return this.http.post(`${this.url}/user/register`, data);
  }

  registerAdmin(firstname, lastname, username, password, tell, mail, foto, type, agencyname, country, city, street, mb){

    const data={
      firstname: firstname,
      lastname: lastname,
      username: username,
      password: password,
      tell: tell,
      mail: mail,
      foto: foto,
      type: type,
      agencyname: agencyname,
      country: country,
      city: city,
      street: street,
      mb: mb
    }

    return this.http.post(`${this.url}/user/registerAdmin`, data);
  }

  getUsers(){
    return this.http.post(`${this.url}/user/getAllUsers`, null);
  }

  deleteUser(username){

    const data={
      username: username
    }

    return this.http.post(`${this.url}/user/delete`, data);
  }

  setStatus(username, status){

    const data={
      username: username,
      status: status
    }

    return this.http.post(`${this.url}/user/setStatus`, data);
  }

  getAllMachines(){
    return this.http.post(`${this.url}/machine/getAllMachines`, null);
  }

  search(type, users){

    if(type!="" && type!=5){
      users = users.filter(ws=>parseInt(ws.type)==type);
    }

    return users;
  }

  getAllStorages(){
    return this.http.post(`${this.url}/storage/getAllStorages`, null);
  }

  getStockFromStorage(ids){

    const data={
      ids: ids
    }

    return this.http.post(`${this.url}/stock/getStockFromStorage`, data);
  }

  getProductsFromStorage(idparr){

    const data={
      idparr: idparr
    }

    return this.http.post(`${this.url}/product/getProductsFromStorage`, data);
  }

  getAllLocations(){
    return this.http.post(`${this.url}/location/getAllLocations`, null);
  }

  getAllReqByIds(ids){

    const data={
      ids: ids
    }
    
    return this.http.post(`${this.url}/req/getAllReqByIds`, data);
  }

  getAllUsersByUNs(usernames){

    const data={
      usernames: usernames
    }

    return this.http.post(`${this.url}/user/getAllUsersByUNs`, data);
  }

  getAllMachineUnitsByIds(ids){

    const data={
      ids: ids
    }

    return this.http.post(`${this.url}/machine/getAllMachineUnitsByIds`, data);

  }

  getReq(ids, idu){

    const data = {
      ids: ids,
      idu: idu
    }

    return this.http.post(`${this.url}/req/getReq`, data);
  }

  getReqByUsername(idu){

    const data = {
      idu: idu
    }

    return this.http.post(`${this.url}/req/getReqByUsername`, data);
  }

  getAllMachinesByIds(ids){

    const data={
      ids: ids
    }

    return this.http.post(`${this.url}/machine/getAllMachinesByIds`, data);

  }

  getAllCars(){

    return this.http.post(`${this.url}/machine/getAllCars`, null);
  }

  getMap(idmu){
    const data={
      idmu: idmu
    }
    return this.http.post(`${this.url}/machine/getMap`, data);
  }

  getProductByNames(names){

    const data={
      names: names
    }
    return this.http.post(`${this.url}/product/getProductByNames`, data);
  
  }

  getTotalStockQuant(ids){

    const data = {
      ids: ids
    }
    return this.http.post(`${this.url}/stock/getTotalStockQuant`, data);

  }

  getSaleForMachineUnit(idmu){

    const data = {
      idmu: idmu
    }
    return this.http.post(`${this.url}/sale/getSaleForMachineUnit`, data);

  }

  getAllMapsByIds(ids){
    const data = {
      ids: ids
    }
    return this.http.post(`${this.url}/machine/getAllMapsByIds`, data);
  }

  insertOrderReq(dos1, dos2, date, sec, txt){
    const data = {
      dos1: dos1,
      dos2: dos2,
      date: date,
      sec: sec,
      txt: txt
    }
    return this.http.post(`${this.url}/user/insertOrderReq`, data);
  }

  getDistributionOrders(dos1){
    const data = {
      dos1: dos1
    }
    return this.http.post(`${this.url}/user/getDistributionOrders`, data);
  }

  updateStatusDisOrder(id, status){
    const data = {
      id: id, 
      status: status
    }
    return this.http.post(`${this.url}/user/updateStatusDisOrder`, data);
  }


  getAllLocationsForMUID(id){
    const data = {
      id: id
    }
    return this.http.post(`${this.url}/location/getAllLocationsForMUID`, data);
  }

  insertClientReq(username, type, cvan, mtype, addres){

    const data = {
      username: username, 
      type: type,
      cvan: cvan,
      mtype: mtype, 
      addres: addres
    }
    return this.http.post(`${this.url}/user/insertClientReq`, data);
  }

  getClientReq(){
    return this.http.post(`${this.url}/user/getClientReq`, null)
  }

  insertLocation(x, y,name, addr, idrr, idsr){
    const data = {
      x: x, 
      y: y,
      name: name,
      addr: addr, 
      idRR: idrr,
      idSR: idsr
    }
    return this.http.post(`${this.url}/location/insertLocation`, data);
  }

  deleteClientReq(id){
    const data = {
      id: id
    }
    return this.http.post(`${this.url}/user/deleteClientReq`, data);
  }

  updateStatus(id, status){
    const data = {
      id: id,
      status: status
    }
    return this.http.post(`${this.url}/req/updateStatus`, data);
  }

}
