import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { ClientReq } from '../models/clientreq';

@Component({
  selector: 'app-adminrequests',
  templateUrl: './adminrequests.component.html',
  styleUrls: ['./adminrequests.component.css']
})
export class AdminrequestsComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Registracija","Prodaja","Izdavanje", "Nabavka"];
  clientReq: ClientReq[] = [];
  orgclientReq: ClientReq[] = [];

  mod: number = 1;


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status==0);
    });

    this.service.getClientReq().subscribe((r: ClientReq[])=>{
      this.clientReq = r;
      this.orgclientReq = r.slice();
      console.log(r)
    });

  }

  search(i){
    this.mod = i;
    this.curr = i-1;
    //sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    if(i==1){
      this.listUsers = this.allUsers.filter(w=>w.status==0 && w.type!=5);
    }else if(i==2){
      this.clientReq = this.orgclientReq.slice();
      this.clientReq = this.clientReq.filter(elem=>elem.type=="buy");
    }else if(i==3){
      this.clientReq = this.orgclientReq.slice();
      this.clientReq = this.clientReq.filter(elem=>elem.type=="rent");
    }
    
  }


}
