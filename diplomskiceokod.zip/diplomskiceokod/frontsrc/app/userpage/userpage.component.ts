import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {
  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Dostavljaci", "Majstori"];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    sessionStorage.setItem('curruserdetails',JSON.stringify(this.loginuser));

    sessionStorage.setItem('currlocationdetails',JSON.stringify(null));

    this.router.navigate(['/userdetails']);

  }

  search(i){
    this.curr = i-1;
    sessionStorage.setItem('currlocationdetails',JSON.stringify(null));
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type=== (this.curr+3));
  }

}
