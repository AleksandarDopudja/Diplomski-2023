import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  usertype: string="";
  usertypenum: number = 0;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    var t = parseInt(JSON.parse(sessionStorage.getItem('usertype')));
    this.usertypenum = t;
    if(t==1){
      this.usertype = "klijenta";
    }else if(t==2){
      this.usertype = "organizatora";
    }else if(t==3){
      this.usertype = "dostavljaca";
    }else{
      this.usertype = "majstora";
    }
  }

  firstname: string = '';
  lastname: string = '';
  username: string = '';
  password: string = '';
  password2: string = '';
  mail: string = '';
  tell: string = '';
  agencyname: string = '';
  country: string = '';
  city: string = '';
  street: string = '';
  about: string = '';
  mb: string = '';
  type: number = 0;
  foto: string = '';

  width:number = 0;
  height:number = 0;

  radio: number = -1;
  radio2: boolean = false;

  message: string = '';
  msg: string = '';

  register(){

    this.type = this.radio;

    if(this.username=='' || this.password=='' || this.password2=='' || this.mail==''){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.radio==1 && (this.firstname=='' || this.lastname=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.radio==2 && (this.agencyname==''||this.country==''||this.city==''||this.street=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.password!=this.password2 ){
      this.message = "Neispravna potvrda lozinke!"
      return false;
    }

    //if(this.tell!=""){
      //if(/^\d\d\d-\d\d\d-\d{3,4}$/.test(this.tell) == false) {
        //this.message = 'Unesite telefon u formatu: xxx-xxx-xxx(x)';
        //return false;
      //}
    //}

    if(/\w@\w/.test(this.mail) == false) {
      this.message = 'Unesite validan mejl sa @!';
      return false;
    }

    if(this.password.length < 7) {
      this.message = 'Lozinka mora sadržati bar 7 karaktera!';
      return false;
    }
    if(this.password.length > 12) {
      this.message = 'Lozinka ne sme sadrzati vise od 12 karaktera!';
      return false;
    }
    if(/[a-z]/.test(this.password) == false) {
      this.message = 'Lozinka mora počinjati slovom!';
      return false;
    }
    if(/[A-Z]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
      return false;
    }
    if(/[\d{+}]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 broj!';
      return false;
    }
    if(/[^a-zA-Z\d]/.test(this.password) == false ) {
      this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
      return false;
    }

    //if(this.radio==2 && /^\d+$/.test(this.mb)){
      //this.message = 'Maticni broj firme moze da sadrzi iskljucivo cifre!'
      //return false;
    //}

    if(this.radio==2 && this.mb.length!=8){
      this.message = 'Maticni broj firme mora da sadrzi 8 cifara!'
      return false;
    }

    if(this.loginuser.type==5){
      this.service.registerAdmin(this.firstname, this.lastname, this.username, this.password, this.tell, this.mail, "", this.usertypenum, "", this.country, this.city, this.street, this.mb).subscribe((resp)=>{
     
        if(resp['message']=='user added'){
          this.message = "Uspesno dodat nov korisnik!";
          //this.router.navigate(['']);
          return true;
        }else{
          this.msg = resp['message'];
          return false;
        }
      
      });      
    }   
    else if(this.loginuser.type==2){
      this.service.register(this.firstname, this.lastname, this.username, this.password, this.tell, this.mail, "", this.type, this.agencyname, this.country, this.city, this.street, this.mb).subscribe((resp)=>{
            
        if(resp['message']=='user added'){
          this.message = "Uspesno ste poslali zahtev za registraciju! Adminstrator ce u najkracem roku obraditi vas zahtev!";
          //this.router.navigate(['']);
          return true;
        }else{
          this.msg = resp['message'];
          return false;
        }
      });
    }

    return false; 
  }

}
