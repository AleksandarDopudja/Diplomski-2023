import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { User } from '../models/user';
import { Car } from '../models/car';

@Component({
  selector: 'app-garage',
  templateUrl: './garage.component.html',
  styleUrls: ['./garage.component.css']
})
export class GarageComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";
  types: string[] = ["Klijenti","Organizatori","Dostavljaci", "Majstori"];

  cars: Car[]= [];


  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status!=0 && w.type!=5 && w.type==1);
    });

    this.service.getAllCars().subscribe((cars: Car[])=>{
      this.cars = cars;
    })

  }

  search(i){
    this.curr = i-1;
    sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type!=5);
    this.listUsers = this.service.search(i, this.listUsers);
  }

}
