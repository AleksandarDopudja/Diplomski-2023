import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { ClientReq } from '../models/clientreq';
import mapboxgl from 'mapbox-gl';

@Component({
  selector: 'app-clinetreqdetails',
  templateUrl: './clinetreqdetails.component.html',
  styleUrls: ['./clinetreqdetails.component.css']
})
export class ClinetreqdetailsComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  clientReq: ClientReq = null;
  marker: mapboxgl.Marker;
  map: mapboxgl.Map;
  lg:number;
  lt:number;

  name: string = "";
  msg: string="";

  ngOnInit(): void {

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.clientReq = JSON.parse(sessionStorage.getItem('currclientreq'));

    const link1 = document.createElement('link');
    link1.href = 'https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.css';
    link1.rel = 'stylesheet';
    document.head.appendChild(link1);

    const link2 = document.createElement('link');
    link2.href = 'https://cdn.jsdelivr.net/npm/vue-mapbox@latest/dist/vue-mapbox.css';
    link2.rel = 'stylesheet';
    document.head.appendChild(link2);

    this.map = new mapboxgl.Map({
      container: 'map-container',
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [20.452767, 44.815209],
      zoom: 12,
      accessToken:"pk.eyJ1IjoiZG9wMTExMSIsImEiOiJjbG10YmVqYzQwMXhmMnFvYzQ4eWJweDlqIn0.3_ZmWiQ63tfsejN2Ak4RPA"
    });

    this.marker = new mapboxgl.Marker({
      color: 'red'  // Postavite boju markera
    });


    
    this.map.on('click', (event) => {
      const { lng, lat } = event.lngLat;
    
      // Uklonite prethodni marker ako postoji
      if (this.marker) {
        this.marker.remove();
      }
    
      // Kreirajte novi marker na koordinatama klika
      this.marker = new mapboxgl.Marker().setLngLat([lng, lat]).addTo(this.map);
    });

    this.map.on('click', (event) => {
     
        const { lng, lat } = event.lngLat;
    
        this.lg = lng;
        this.lt = lat;

        // Uklonite prethodni marker ako postoji
        if (this.marker) {
          this.marker.remove();
        }
    
        // Kreirajte novi marker na koordinatama klika
        this.marker = new mapboxgl.Marker().setLngLat([lng, lat]).addTo(this.map);
      
    });

   

  }

  accept(){
    this.service.insertLocation(this.lt, this.lg, this.name, this.clientReq.addres, ['65250bc2c9cd491939d7f37d'], []).subscribe((resp)=>{
      this.service.deleteClientReq(this.clientReq._id).subscribe((resp)=>{
        
        this.service.updateStatus("65250bc2c9cd491939d7f37d",1).subscribe((resp)=>{
          this.msg = "Uspesno!"
        })
      });
    });
  }

  dismiss(){
    console.log(this.clientReq._id);
    this.service.deleteClientReq(this.clientReq._id).subscribe((resp)=>{
      this.msg = "Odbijen zahtev!"
    });
  }
}
