import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../servicesforsys/userservice.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Location } from '../models/location';
import mapboxgl from 'mapbox-gl';

@Component({
  selector: 'app-alllocations',
  templateUrl: './alllocations.component.html',
  styleUrls: ['./alllocations.component.css']
})
export class AlllocationsComponent implements OnInit {

  constructor(private service: UserserviceService, private router: Router) { }

  loginuser: User;
  curr: number = 0;
  allUsers: User[] = [];
  listUsers: User[] = [];
  searchname: string = "";

  allloactions: Location[] = [];

  markers: mapboxgl.Map[]=[];

  lastclkmarker: number = -1;

  currlocation: Location = null;


  changeMarkerColor(index: number, c: string) {
    const pathElement = this.markers[index].getElement().querySelector('path');
    pathElement.style.fill = c;  // Postavite boju fill-a na crvenu
  }

  ngOnInit(): void {

    const link1 = document.createElement('link');
    link1.href = 'https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.css';
    link1.rel = 'stylesheet';
    document.head.appendChild(link1);

    const link2 = document.createElement('link');
    link2.href = 'https://cdn.jsdelivr.net/npm/vue-mapbox@latest/dist/vue-mapbox.css';
    link2.rel = 'stylesheet';
    document.head.appendChild(link2);

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsers().subscribe((users: User[])=>{
      this.allUsers = users;
      this.listUsers = users.filter(w=>w.status!=0 && w.type==3);
    });

    this.service.getAllLocations().subscribe((locations: Location[])=>{
      this.allloactions = locations;

      const map = new mapboxgl.Map({
        container: 'map-container',
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [20.452767, 44.815209],
        zoom: 12,
        accessToken:"pk.eyJ1IjoiZG9wMTExMSIsImEiOiJjbG10YmVqYzQwMXhmMnFvYzQ4eWJweDlqIn0.3_ZmWiQ63tfsejN2Ak4RPA"
      });

      map.on('click', function(e) {
        //this.currlocation = null;
      });

      this.allloactions.forEach((location, index) => {
        const marker = new mapboxgl.Marker({color:'blue'})
          .setLngLat([location['y'], location['x']])
          .addTo(map);
  
        this.markers.push(marker);
  
        // Dodajemo klasu na marker
        const markerElement = marker.getElement();

        markerElement.addEventListener('click', () => {
          // Dodajte svoju logiku za klik na marker
          if(this.lastclkmarker==index)return;

          this.changeMarkerColor(index, "red");

          if(this.lastclkmarker != -1){
            this.changeMarkerColor(this.lastclkmarker, "blue");
          }

          this.lastclkmarker = index;
          //alert(index);
          this.currlocation = this.allloactions[index];
        });
      });


    })



    // const marker = new mapboxgl.Marker()
    // .setLngLat([20.452767, 44.815209]) // Koordinate za neku ulicu u Beogradu
    // .addTo(map);

    // marker.getElement().addEventListener('click', () => {
    //   alert("Clicked");
    // });

    // const marker2 = new mapboxgl.Marker({color: "#FFFFFF"})
    // .setLngLat([20.453202, 44.820069]) // Koordinate za neku ulicu u Beogradu
    // .addTo(map);

    //alert(this.allloactions.length);

  }

  search(i){
    this.curr = i-1;
    //sessionStorage.setItem('usertype',JSON.stringify(this.curr+1));
    this.listUsers = this.allUsers.filter(w=>w.status!=0 && w.type=== (this.curr+3));
  }

  paintmarker(i){

    if(this.lastclkmarker==i)return;

    this.changeMarkerColor(i, "red");

    if(this.lastclkmarker != -1){
      this.changeMarkerColor(this.lastclkmarker, "blue");
    }

    this.lastclkmarker = i;
    //alert(index);
    this.currlocation = this.allloactions[i];
  }

}


